// Entry point (classic content script). Loads the ES modules via the
// extension URL and wires selection watching to the UI.
(async () => {
  const url = (p) => chrome.runtime.getURL(p);
  const [dom, framesMod, insertMod, ui] = await Promise.all([
    import(url('lib/pitch-dom.js')),
    import(url('lib/frames.js')),
    import(url('lib/insert.js')),
    import(url('lib/ui.js')),
  ]);

  let currentVideo = null;
  let busy = false;

  const STEP_TEXT = {
    geometry: 'Videoposition lesen …',
    drop: 'Frame einfügen …',
    'wait-image': 'Warte auf Pitch-Upload …',
    position: 'Position und Größe setzen …',
    layer: 'Hinter das Video legen …',
    reselect: 'Fertig.',
  };

  async function onButtonClick() {
    if (busy || !currentVideo) return;
    const videoBlock = currentVideo;
    const video = dom.videoElement(videoBlock);
    if (!video) return;
    busy = true;
    let frames = null;
    try {
      ui.openPopup({ frames: null, onCancel: cleanup });
      ui.setProgress('Frames werden gelesen …');
      const started = Date.now();
      for (;;) {
        try { frames = await framesMod.grabFrames(video); break; } catch (e) {
          if (e.message !== 'Video lädt noch' || Date.now() - started > 15000) throw e;
          ui.setProgress('Video lädt noch …');
          await dom.sleep(500);
        }
      }
      const choice = await ui.showFrames(frames);
      if (!choice) { cleanup(); return; }
      await insertMod.insertFrameBehind(videoBlock, choice.blob, (step) => ui.setProgress(STEP_TEXT[step] || step));
      ui.setProgress('Frame liegt hinter dem Video ✓');
      await dom.sleep(1500);
      cleanup();
    } catch (e) {
      console.error('[previs]', e);
      ui.setError(`${e.message} – Bild ggf. manuell prüfen oder mit ⌘Z zurücknehmen.`);
      busy = false;
      framesMod.revokeFrames(frames);
    }
    function cleanup() {
      ui.closePopup();
      framesMod.revokeFrames(frames);
      busy = false;
    }
  }

  let scheduled = false;
  function check() {
    scheduled = false;
    const block = dom.selectedVideoBlock();
    currentVideo = block;
    if (block) ui.showButton(dom.toolbar(), block, onButtonClick);
    else ui.hideButton();
  }
  new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(check);
  }).observe(document.body, { attributes: true, attributeFilter: ['class', 'style'], childList: true, subtree: true });
  check();
})();
